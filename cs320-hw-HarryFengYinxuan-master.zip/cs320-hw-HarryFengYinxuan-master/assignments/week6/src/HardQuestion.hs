module HardQuestion where

-- have you filled out the survey? https://goo.gl/forms/YoIrFKY19dCSDcxg1
haveYouFilledOutTheSurvey:: Bool
haveYouFilledOutTheSurvey = True
