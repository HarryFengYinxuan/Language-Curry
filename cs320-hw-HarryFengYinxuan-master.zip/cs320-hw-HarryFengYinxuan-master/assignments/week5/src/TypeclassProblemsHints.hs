module TypeclassProblemsHints where

-- the following functions should be helpful for "AllTheThings (a,b)"
allTuples :: [a] -> [b] -> [(a,b)]
allTuples = undefined

-- this function may be helpful for allTuples
stickInFront :: a -> [b] -> [(a, b)]
stickInFront  = undefined