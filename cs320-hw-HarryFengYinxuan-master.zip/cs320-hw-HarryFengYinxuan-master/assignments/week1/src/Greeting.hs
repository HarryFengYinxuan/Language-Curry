module Greeting where


-- how do you greet someone?
greeting = "undefined"

-- finish the identity function
ident x = x
