# Class Survey

1. What is your name?

# Yinxuan Feng

2. What is your bu-id?

U17037273

3. What programming languages do you know?

Proficient in Python, Arduino, JQuery, Django, C#, C, Linux and familiar with Computer Forensics, IoT, ML, Computer Vision, Matlab, Unity, Assembly, bash, C++, JS, HTML, CSS, SQL, java, and others

4. Do you have any particular interests in CS that you intend to pursue (e.g, machine learning, security, software development, etc.)?

ML, and everything. 

I was in BU Spark! as a paid programmer. Completed a semester-long team project. Designed the Minimum Viable Product (MVP) of an Android app that helps the users to improve their basketball skills by Computer Vision (CV). Defined Java data structures specific to our app. Created a web API for OpenCV libraries using the Django framework. Implemented design techniques such as wireframe, flow chart, function analysis, Crazy Eights. Implemented team management techniques. I worked for Spark! before I switched my major to CS.

I am a member of Builds, 0xBU. Participated in competition events, practiced skills with real Capture the Flag (CTF) challenges. Performed cipher decoding, web security test, binary exploitation, computer forensics. Used gdb, Wireshark, John the Ripper, TestDisk, HTTPie, Radare, Exiftool, and such.

I am the secretary of BU AR/VR. Researched on Augmented Reality (AR) and Virtual Reality (VR) technology. Started a project that can use physical human hands to interact with virtual objects in VR and AR (made happen by Leapmotion). The project was presented at the first BU VR festival, and got the first place; a prize of Acer Mixed Reality (MR) headset was won after shaking hands with the head of the CS department. DIYed AR mind palace which allows the user to put AR sticky notes inside a room.

I am an Undergraduate Research Assistant at Nano Structure Fiber Lab. Analyzed Non-Linear Fiber images to estimate its alignment. Build an Arduino circuit to interface with a Piezo stage using Digital to Analog Converter (DAC). Interfaced Thor Labs Optical Cameras and Powermeters with a PC using Labview.

5. For the programming language that you use the most, what do you like MOST about the language?

Python

6. For the programming language that you use the most, what do you like LEAST about the language?

Java, because I haven't found an IDE that does auto-complete. Also, labview and matlab.

7. What would you like to learn from this class?

bindings
