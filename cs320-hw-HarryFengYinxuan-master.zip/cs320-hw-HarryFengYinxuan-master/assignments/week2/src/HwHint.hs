module HwHint where
import Prelude(Show, undefined)
import Hw(List)

-- you will likely need to define the following helper function, 
-- you can copy and paste it into the main assignment

-- Concatenate two lists, make sure it works
-- if either or both are empty
append :: (List a) -> (List a) -> (List a)
append  _ _  = undefined
